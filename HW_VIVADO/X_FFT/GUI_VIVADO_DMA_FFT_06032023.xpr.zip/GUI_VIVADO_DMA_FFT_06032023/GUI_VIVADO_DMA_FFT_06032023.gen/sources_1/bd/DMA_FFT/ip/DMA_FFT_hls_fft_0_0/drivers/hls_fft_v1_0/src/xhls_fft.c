// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xhls_fft.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XHls_fft_CfgInitialize(XHls_fft *InstancePtr, XHls_fft_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XHls_fft_Start(XHls_fft *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHls_fft_ReadReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_AP_CTRL) & 0x80;
    XHls_fft_WriteReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XHls_fft_IsDone(XHls_fft *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHls_fft_ReadReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XHls_fft_IsIdle(XHls_fft *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHls_fft_ReadReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XHls_fft_IsReady(XHls_fft *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHls_fft_ReadReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XHls_fft_EnableAutoRestart(XHls_fft *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHls_fft_WriteReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XHls_fft_DisableAutoRestart(XHls_fft *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHls_fft_WriteReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_AP_CTRL, 0);
}

void XHls_fft_Set_size(XHls_fft *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHls_fft_WriteReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_SIZE_DATA, Data);
}

u32 XHls_fft_Get_size(XHls_fft *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHls_fft_ReadReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_SIZE_DATA);
    return Data;
}

void XHls_fft_InterruptGlobalEnable(XHls_fft *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHls_fft_WriteReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_GIE, 1);
}

void XHls_fft_InterruptGlobalDisable(XHls_fft *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHls_fft_WriteReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_GIE, 0);
}

void XHls_fft_InterruptEnable(XHls_fft *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHls_fft_ReadReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_IER);
    XHls_fft_WriteReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_IER, Register | Mask);
}

void XHls_fft_InterruptDisable(XHls_fft *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHls_fft_ReadReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_IER);
    XHls_fft_WriteReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_IER, Register & (~Mask));
}

void XHls_fft_InterruptClear(XHls_fft *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    //XHls_fft_WriteReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_ISR, Mask);
}

u32 XHls_fft_InterruptGetEnabled(XHls_fft *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHls_fft_ReadReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_IER);
}

u32 XHls_fft_InterruptGetStatus(XHls_fft *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    // Current Interrupt Clear Behavior is Clear on Read(COR).
    return XHls_fft_ReadReg(InstancePtr->Control_BaseAddress, XHLS_FFT_CONTROL_ADDR_ISR);
}

