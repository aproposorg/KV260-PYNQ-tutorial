// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xhls_fft.h"

extern XHls_fft_Config XHls_fft_ConfigTable[];

XHls_fft_Config *XHls_fft_LookupConfig(u16 DeviceId) {
	XHls_fft_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XHLS_FFT_NUM_INSTANCES; Index++) {
		if (XHls_fft_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XHls_fft_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHls_fft_Initialize(XHls_fft *InstancePtr, u16 DeviceId) {
	XHls_fft_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHls_fft_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHls_fft_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

